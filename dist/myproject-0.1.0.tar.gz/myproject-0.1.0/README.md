Not yet ready to be used. This is a work in progress.

# python-webcitizen-audit
Python library. HTML is the input, a set of audits are performed. Results are returned in a score or detailed score.
