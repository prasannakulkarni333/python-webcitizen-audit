# import requests

# obj = url(url="https://acquia.com", html=requests.get("https://acquia.com").text)
# m = obj.json_nltk2()
# print((m))

# print(json_html2(requests.get("https://acquia.com").text))
